//1.algoritmo para imprimir numeros del 1 al 10
let i = 0
while (i <= 10) {
    console.log(i);
    i++;
}