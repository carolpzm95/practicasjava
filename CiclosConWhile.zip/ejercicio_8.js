//8.escribe una funcion que calcule la media aritmetica(promedio) de los numeros en un array
let numeros =[3,5,7,2,8,9,10,12,15,20];
let acumulador=0;
let i=0;
function promedio () {
    
while(i<numeros.length){
    acumulador+=numeros[i];
    i++;
    
}
let promedio=acumulador/numeros.length
return promedio
}
console.log(promedio());