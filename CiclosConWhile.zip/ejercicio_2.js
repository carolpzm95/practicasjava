//algoritmo para calcular la suma de los 10 numeros
let suma=0
let i=0
while(i<=9){
    suma+=i;
    console.log("la suma es:"+suma);
    i++;
}