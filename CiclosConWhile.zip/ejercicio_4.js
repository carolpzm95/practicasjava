//4.algoritmo para contar ocurrencias del 'a'en un texto
let texto="carolina";
let i=0;
let contador=0;
while(i<texto.length){
    let valor=texto[i].toLowerCase();
    if(valor=="a"){
        contador++;
        i++;
    }
}
console.log('encontre'+contador+'letras vocales a');