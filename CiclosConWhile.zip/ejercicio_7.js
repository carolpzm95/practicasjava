// 7.sacar el numero mas grande de la lista//
let numeros=[3,5,7,2,8,9,10,12,15,20];
let i=1;
function numeroGrande(array){
    let numeroGrande=0
    while(i<numero.lenght){
        if(numero[i]>numero[i-1]){
            numeroGrande=numero[i]
        }
        i++
    }
    return numeroGrande
}
console.log(numerogrande(numero));