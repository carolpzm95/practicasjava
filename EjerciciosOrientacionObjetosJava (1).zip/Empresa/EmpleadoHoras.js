const Empleados = require('./Empleados.js');

class EmpleadoHora extends Empleados {
    #horasTrabajadas;

    /**
     * @param {number} codigoEmpleado - the unique identification of the employee
     * @param {string} nombre - the name of the employee
     * @param {number} salarioBase - The base salary of the employee (pago por hora)
     * @param {number} horasTrabajadas - the hours worked by the employee
     */
    constructor(codigoEmpleado, nombre, salarioBase, horasTrabajadas) { 
        super(codigoEmpleado, nombre, salarioBase);
        this.#horasTrabajadas = horasTrabajadas;
    }

    set horasTrabajadas(horasTrabajadas) {
        this.#horasTrabajadas = horasTrabajadas;
    }

    get horasTrabajadas() {
        return this.#horasTrabajadas;
    }

    calcularSalario() {
        const salarioTotal = this.SalarioBase * this.#horasTrabajadas; 
        return salarioTotal;
    }
}

module.exports = EmpleadoHora;