const Empleados = require('./Empleados.js');

class EmpleadoTiempoCompleto extends Empleados {

    /**
     * @param {interger} codigoEmpleado - the unique identification of the employee
     * @param {string} nombre - the name of the employee
     * @param {interger} salarioBase - base salary of the employee
     */
    constructor(codigoEmpleado, nombre, salarioBase) {  
        super(codigoEmpleado, nombre, salarioBase);
    }

    calcularSalario() {
        return this.SalarioBase; 
    }
}

module.exports = EmpleadoTiempoCompleto;