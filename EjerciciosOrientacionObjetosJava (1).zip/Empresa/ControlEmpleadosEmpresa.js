const EmpleadoTiempoCompleto = require('./EmpleadoTiempoCompleto.js');
const EmpleadoHora = require('./EmpleadoHoras.js');

const empleadoTiempoCompleto1 = new EmpleadoTiempoCompleto(1, "Amanda Jimenez", 1500000);
const empleadoHora1 = new EmpleadoHora(2, "Julio Meneses", 25000, 8);

console.log(`Salario empleado fijo (${empleadoTiempoCompleto1.Nombre}): $${empleadoTiempoCompleto1.calcularSalario()}`);
console.log(`Salario empleado por hora (${empleadoHora1.Nombre}): $${empleadoHora1.calcularSalario()}`);