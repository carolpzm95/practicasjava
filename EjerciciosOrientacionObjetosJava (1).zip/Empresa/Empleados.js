class Empleados {
    #codigoEmpleado
    #nombre
    #salarioBase

    /**
     * @param {number} codigoEmpleado - the unique identification of the employee
     * @param {string} nombre - the name of the employee
     * @param {number} salarioBase - The base salary of the employee
     */
    constructor(codigoEmpleado, nombre, salarioBase) {
        this.#codigoEmpleado = codigoEmpleado;
        this.#nombre = nombre;
        this.#salarioBase = salarioBase;
    }

    set Nombre(nombre) {
        this.#nombre = nombre;
    }

    set CodigoEmpleado(codigoEmpleado) {
        this.#codigoEmpleado = codigoEmpleado;
    }

    set SalarioBase(salarioBase) {
        this.#salarioBase = salarioBase;
    }

    get Nombre() {
        return this.#nombre;
    }

    get CodigoEmpleado() {
        return this.#codigoEmpleado;
    }

    get SalarioBase() {
        return this.#salarioBase;
    }

    calcularSalario() {
        return this.#salarioBase;
    }
}

module.exports = Empleados;
