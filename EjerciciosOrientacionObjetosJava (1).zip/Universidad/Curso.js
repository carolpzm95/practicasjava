class Curso{
    #nombre;
    #codigo;
    #numCreditos;

    /**
     * @params
     * @param nombre{string} - the name of the course
     * @param codigo{string} - the unique code identification of the course
     * @param numCreditos{int} -The number of credits for the course. This can be used to calculate a student's total credits.
     * 
     */

    constructor(nombre, codigo, numCreditos){
        this.#nombre = nombre;
        this.#codigo = codigo;
        this.#numCreditos = numCreditos;
    }

    set nombre(nombre){
        this.#nombre = nombre;
    }

    set codigo(codigo){
        this.#codigo = codigo;
    }

    set numCreditos(numCreditos){
        this.#numCreditos = numCreditos;
    }

    get nombre(){
        return this.#nombre;
    }

    get codigo(){
        return this.#codigo;
    }

    get numCreditos(){
        return this.#numCreditos;
    }
}

module.exports = Curso;