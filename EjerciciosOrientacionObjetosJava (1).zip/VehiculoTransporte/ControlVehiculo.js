const VehiculoTerrestre = require('./VehiculoTerrestre.js');
const VehiculoAcuatico = require('./VehiculoAcuatico.js');

const auto = new VehiculoTerrestre("Renault", "Logan", 4, 4);
console.log(auto.moverse());
console.log(auto.frenar());

const barco = new VehiculoAcuatico("Fibratec", "Cartagena 450", 8, "motor fuera de borda");
console.log(barco.moverse());
console.log(barco.anclar());