class Vehiculo {
    #marca;
    #modelo;
    #capacidad;

    /**
     * @param {string} marca - the vehicle brand
     * @param {string} modelo - the model of the vehicle
     * @param {Interger} capacidad - the capacity of passengers
     */
    constructor(marca, modelo, capacidad) {
        this.#marca = marca;
        this.#modelo = modelo;
        this.#capacidad = capacidad;
    }

    set Marca(marca) {
        this.#marca = marca;
    }

    set Modelo(modelo) {
        this.#modelo = modelo;
    }

    setCapacidad(capacidad) {
        this.#capacidad = capacidad;
    }

    get Marca() {
        return this.#marca;
    }

    get Modelo() {
        return this.#modelo;
    }

    get Capacidad() {
        return this.#capacidad;
    }

    moverse() {
        return "El vehículo se está moviendo";
    }
}

module.exports = Vehiculo;