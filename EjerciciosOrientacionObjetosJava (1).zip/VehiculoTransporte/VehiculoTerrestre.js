const Vehiculo = require('./Vehiculo.js');
class VehiculoTerrestre extends Vehiculo {
    #NumRuedas;
    
    /**
     * @param {Float} marca - The brand of the vehicle 
     * @param {Float} modelo -  The model of the vehicle
     * @param {Interger} capacidad - The passengers Capacity
     * @param {Interger} NumRuedas - The number of wheels of the vehicle
      */
    constructor(marca, modelo, capacidad, NumRuedas) {
        super(marca, modelo, capacidad);
        this.#NumRuedas = NumRuedas;
    }
    set NumRuedas(NumRuedas) {
        this.#NumRuedas = NumRuedas;
    }
     get NumRuedas() {
        return this.#NumRuedas;
    }

    frenar() {
        return `${this.Marca} ${this.Modelo} está frenando`;
    }

    moverse() {
        return`${this.Marca} ${this.Modelo} se desplaza por tierra con ${this.NumRuedas} ruedas.`;
    }
}

module.exports = VehiculoTerrestre;