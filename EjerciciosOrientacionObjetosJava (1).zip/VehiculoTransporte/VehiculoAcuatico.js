const Vehiculo = require('./Vehiculo.js');
class VehiculoAcuatico extends Vehiculo {
    #tipoPropulsion;
    /**
     * @param {float} marca -the brand of the vehicle
     * @param {float} modelo - the model of the vehicle
     * @param {interger} capacidad - the capicity of the passengers
     * @param {float} tipoPropulsion -Type of propulsion of the watercraft
     */

    constructor(marca, modelo, capacidad, tipoPropulsion) {
        super(marca, modelo, capacidad);
        this.#tipoPropulsion = tipoPropulsion;
    }

    set TipoPropulsion(tipoPropulsion) {
        this.#tipoPropulsion = tipoPropulsion;
    }

    get TipoPropulsion() {
        return this.#tipoPropulsion;
    }

    anclar() {
        return `${this.Marca} ${this.Modelo} está anclando`;
    }

    moverse() {
        return `${this.Marca} ${this.Modelo} navega por agua`;
    }
}

module.exports = VehiculoAcuatico;