const Automovil = require('./Automovil');
console.log("Sistema de Control de Automovil");


const auto1 = new Automovil("Logan", "Renault", 2023, "Blanco", 1600, "Gasolina", 115);
const auto2 = new Automovil("Onix", "Chevrolet", 2024, "Gris", 1000, "Gasolina", 77);
const auto3 = new Automovil("Sandero", "Renault", 2022, "Rojo", 1600, "Gasolina", 110);

function probarAutomovil(auto) {
    auto.encender();
    auto.acelerar();
    auto.apagar();
}

probarAutomovil(auto1);
probarAutomovil(auto2);
probarAutomovil(auto3);