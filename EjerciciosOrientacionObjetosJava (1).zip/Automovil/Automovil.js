const Motor = require('./Motor');
class Automovil{
    #modelo
    #marca
    #year
    #color
    #motor
/**
 * @param{texto}modelo-the model of the car
 * @param{texto}marca-the brand of the car
 * @param{int}year-the year the car was launched
 * @param{texto}color-the color of the car
 * @param[motor]motor-the engine of the car
 */
constructor(modelo,marca,year,color, cilindraje, tipoCombustible, potencia){
    this.modelo = modelo;
     this.marca = marca;
     this.year = year;
     this.color = color;
     this.motor = new Motor(cilindraje, tipoCombustible, potencia);
    }
 encender() {
    console.log("El automóvil " + this.#marca + " " + this.#modelo + " esta encendido");
    }

    acelerar() {
     console.log("El automóvil " + this.#marca + " " + this.#modelo + " esta acelerando");
    }

    apagar() {
        console.log("El automóvil " + this.#marca + " " + this.#modelo + " esta apagado");
    }
 set modelo(modelo) {
        this.#modelo = modelo;
    }

     set marca(marca) {
        this.#marca = marca;
    }
     set year ( year) {
        this.#year = year;
    }

     set color(color) {
        this.#color = color;
    }

    set motor(motor) {
        this.#motor = motor;
    }
    get modelo() {
        return this. #modelo;
    }

     get marca() {
        return this.#marca;
    }

    get year() {
        return this. #year;
    }

    get color() {
        return this.#color;
     }
       get motor() {
        return this. #motor;
    } 
}
      module.exports=Automovil; 
