class Motor {
    #cilindraje;
    #tipoCombustible;
    #potencia;

    /**
     * @param {float} cilindraje - the engine displacement in cc
     * @param {string} tipoCombustible -The type of fuel
     * @param {float} potencia - the power in hp
     */
     constructor(cilindraje, tipoCombustible, potencia) {
        this.#cilindraje = cilindraje;
        this.#tipoCombustible = tipoCombustible;
        this.#potencia = potencia;
    }

    
    set cilindraje(cilindraje) {
        this.#cilindraje = cilindraje;
    }

    set tipoCombustible(tipoCombustible) {
        this.#tipoCombustible = tipoCombustible;
    }

    set potencia(potencia) {
        this.#potencia = potencia;
    }

    get cilindraje() {
        return this.#cilindraje;
    }

    get tipoCombustible() {
        return this.#tipoCombustible;
    }

    get potencia() {
        return this.#potencia;
    }
}
      module.exports=Motor; 