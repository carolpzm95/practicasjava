class Jugador{
    #nombre
    #posicion
    #NumCamisa
    #Age
    /**
     *@param{texto}nombre-the name of the player
     *@param{float}posicion-the position in the game of the player
     *@param{int}edad-the age of the player
     *@param{interger}NumCamisa- the number of the t-shirt of the player
     *@param{interger}Age-the Age of the player
     */
    constructor(nombre, posicion, Age, NumCamisa){
        this.#nombre = nombre;
        this.#posicion = posicion;
        this.#NumCamisa = NumCamisa;
        this.#Age = Age;
    }
     setNombre(nombre) {
        this.#nombre = nombre;
    }

    setPosicion(posicion) {
        this.#posicion = posicion;
    }

    setAge(Age) {
        this.#Age = Age;
    }

    setNumCamisa(NumCamisa) {
        this.#NumCamisa = NumCamisa;
    }

    getNombre() {
        return this.#nombre;
    }

    getPosicion() {
        return this.#posicion;
    }

    getAge() {
        return this.#Age;
    }

    getNumCamisa() {
        return this.#NumCamisa;
    }
}
    module.exports=Jugador; 


     

