const EquipoFutbol = require('./EquipoFutbol.js');
const Jugador = require('./Jugador.js');

const jugador1 = new Jugador("Luis Díaz", "Extremo Izquierdo", 27, 7);
const jugador2 = new Jugador("James Rodríguez", "Mediocampista", 33, 10);
const jugador3 = new Jugador("Davinson Sánchez", "Defensa Central", 29, 23);

const equipo = new EquipoFutbol("Colombia", "Medellín", "Jhon Bodmer");

equipo.agregarJugador(jugador1);
equipo.agregarJugador(jugador2);
equipo.agregarJugador(jugador3);
equipo.mostrarPlantilla();

console.log("\n-- Removiendo a James Rodríguez del equipo --");
equipo.removerJugador("James Rodríguez");
equipo.mostrarPlantilla();
console.log("\nEl jugador eliminado aún existe fuera del equipo:");
console.log(`Jugador: ${jugador2.getNombre()}, ${jugador2.getPosicion()}, ${jugador2.getAge()} años.`);