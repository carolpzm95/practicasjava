const Jugador = require ("./Jugador.js");

class EquipoFutbol {
    #nombre;
    #ciudad;
    #entrenador;
    #jugadores = [];

    /**
     * @param {string} nombre-the name of the soccer team
     * @param {string} ciudad-the city of the soccer team
     * @param {string} entrenador-the coach of the team
     */

    constructor (nombre, ciudad, entrenador) {
        this.#nombre = nombre;
        this.#ciudad = ciudad;
        this.#entrenador = entrenador;
    }

    set nombre(nombre) {
        this.#nombre = nombre;
    }

    set ciudad(ciudad) {
        this.#ciudad = ciudad;
    }

    set entrenador(entrenador) {
        this.#entrenador = entrenador;
    }

    set Jugadores(jugadores) {
        this.#jugadores = jugadores;
    }   

    get nombre() {
        return this.#nombre;
    }

    get ciudad() {
        return this.#ciudad;
    }

    get entrenador() {
        return this.#entrenador;
    }

    get jugadores() {
        return this.#jugadores;
    }

    agregarJugador(jugador) {
        this.#jugadores.push(jugador);
    }

    removerJugador(nombreJugador) {
        this.#jugadores = this.#jugadores.filter(j => j.nombre !== nombreJugador);
    }
    
    mostrarPlantilla() {
        console.log(`\nPlantilla del equipo ${this.#nombre}:`);
        this.#jugadores.forEach(j => {
            console.log(`- ${j.getNombre()}, ${j.getPosicion()}, ${j.getAge()} años , camiseta #${j.getNumCamisa()}`);
        });
    }
}
module.exports = EquipoFutbol;