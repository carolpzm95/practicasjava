class Forma{
    #color


/**@param {texto} color-the color of the geometry shape */

constructor(color) {
        this.#color = color;
    }

    getColor() {
        return this.#color;
    }

    setColor(color) {
        this.#color = color;
    }

    calcularArea() {
        return 0;
    }
}
module.exports=Forma; 