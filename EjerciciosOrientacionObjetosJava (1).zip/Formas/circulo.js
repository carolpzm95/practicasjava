const Forma = require('./Forma.js');
class Circulo extends Forma {
    #radio

    /**@param {float} radio-the radius of the geometry shape */
    constructor(color, radio) {
        super(color);
        this.#radio = radio;
    }

    calcularArea() {
        return Math.PI * this.#radio * this.#radio;
    }

    mostrarInformacion() {
        console.log(`Círculo - Color: ${this.getColor()}, Radio: ${this.#radio}, Área: ${this.calcularArea().toFixed(2)}`);
    }
}
module.exports=Circulo; 
