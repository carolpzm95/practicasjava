const Forma= require('./Forma.js');
const Circulo = require('./circulo.js');
const Rectangulo = require('./Rectangulo.js');

const circulo1 = new Circulo("verde", 6);
const rectangulo1 = new Rectangulo("Morado", 10, 4);

circulo1.mostrarInformacion();
rectangulo1.mostrarInformacion();