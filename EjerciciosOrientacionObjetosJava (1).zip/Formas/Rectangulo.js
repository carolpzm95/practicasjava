const Forma = require('./Forma.js');
class Rectangulo extends Forma {
    #largo
    #ancho

/** 
 * @param{float}Largo-the lenght of the geometry shape
 * @param{float} ancho-the width of the geometry shape
*/
    constructor(color, largo, ancho) {
        super(color);
        this.#largo = largo;
        this.#ancho = ancho;
    }

    calcularArea() {
        return this.#largo * this.#ancho;
    }

    mostrarInformacion() {
        console.log(`Rectángulo - Color: ${this.getColor()}, Largo: ${this.#largo}, Ancho: ${this.#ancho}, Área: ${this.calcularArea()}`);
    }
}
module.exports=Rectangulo;