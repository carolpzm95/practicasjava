const Animal = require("./Animal.js");

class Mamifero extends Animal {

    #TipoPelaje

    /**
     * @param {String} Tipopelaje -coat type of the mammal
     * @param {string} nombre -the name of the mammal
     * @param {int} Age-the age od the mammal
     * @param {string} Especie-kind of mammal
     */

    constructor(Tipopelaje, nombre, Age, Especie) {
        super(nombre, Age, Especie);
        this.#TipoPelaje = Tipopelaje;

    }

    set TipoPelaje(Tipopelaje) {
        this.#TipoPelaje = Tipopelaje;
    }

    get TipoPelaje() {
        return this.#TipoPelaje;
    }

    Amamantar() {
        return `El mamifero ${this.Nombre} esta amamantando a sus crías`;
    }
}

module.exports = Mamifero;