class Animal {

    #Nombre;
    #Age
    #Especie;

    /**
     * 
     * @param {string} Nombre -the name of the animal
     * @param {int} Age -the age of the animal
     * @param {string} Especie -the kind of the animal
     */

    constructor(Nombre, Age, Especie) {
        this.Nombre = Nombre;
        this.Age = Age;
        this.Especie = Especie;
    }

    set Nombre(Nombre) {
        this.#Nombre = Nombre;
    }

    set Age(Age) {
        this.#Age = Age;
    }

    set Especie(Especie) {
        this.#Especie = Especie;
    }

    get Nombre() {
        return this.#Nombre;
    }

    get Age() {
        return this.#Age;
    }

    get Especie() {
        return this.#Especie;
    }

    HacerSonido() {
        return `El ${this.#Nombre} esta haciendo sonido`;
    }

    Comer() {
        return `El ${this.#Nombre} esta comiendo`;
    }
}

module.exports = Animal;
