// 6./escribe una funcion que reciba un array de numeros y devuelve un nuevo array de números y devuelva un array que contenga solo los numeros pares
let numeros = [4, 3, 6, 7, 1, 9, 10, 345, 234, 568, 4, 10, 20];

function darmepares(array) {
    let pares = [];
    let i = 0;
    while(i < array.length) {
        if(array[i] % 2 === 0) {
            pares.push(array[i]);
        }
        i++;
    }
    return pares;
}

let arrayNuevo = darmepares(numeros);
console.log(arrayNuevo);