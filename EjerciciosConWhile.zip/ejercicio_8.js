//8.calcularPotencia
function calcularPotencia(base, exponente) {
  let resultado = 1;
  let i = 0;

  while (i < exponente) {
    resultado *= base; 
    i++;               
  }

  return resultado;
}


console.log(calcularPotencia(4, 2));  
console.log(calcularPotencia(8, 4));  
console.log(calcularPotencia(9, 2));  