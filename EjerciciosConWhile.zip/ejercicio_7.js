// 7.suma cuadrados//
function sumaCuadrados(Numero) {
  let suma = 0
  let i = 1

  while (i <= Numero) {
    suma += i * i
    i++
   
  }

  return suma
 
}
console.log(sumaCuadrados(8))
console.log(sumaCuadrados(10))
