//4.algoritmo para contar ocurrencias del 'a'en un texto

let texto = "carolina";
let i = 0;
let contador = 0;
while (i < texto.length) {
    if (texto[i] === "a") {
        contador++;
    }
    i++;
}
console.log(contador);