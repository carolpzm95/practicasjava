//5.algoritmo para calcular el factorial de un numero
let numero = 5
let factorial = 1
let i = 1

while(i <= numero) {
    factorial *= i
    i++
}

console.log("el factorial es: "+factorial);