//8 calcular potencia

function calcularPotencia(base, exponente) {
  let resultado = 1;
  let i = 0;

  do {
    resultado *= base; 
    i++;               
  } while (i < exponente)

  return resultado;
}


console.log(calcularPotencia(4, 8));  
console.log(calcularPotencia(2, 9));  
console.log(calcularPotencia(10, 12));  