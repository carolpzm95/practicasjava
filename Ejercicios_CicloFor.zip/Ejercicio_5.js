let numero = 6;
let factorial=1;
for(let i=1;i<=numero;i++){
    factorial*=i;
}
console.log("el factorial de" +numero+" es:"+ factorial);