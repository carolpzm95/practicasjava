const calcularPotencia = (base, exponente) => {
    if (exponente === 0) return 1;
    let resultado = 1;
    for (let i = 0; i < exponente; i++) {
        resultado *= base;
    }
    return resultado;
}
console.log(calcularPotencia(9, 2))