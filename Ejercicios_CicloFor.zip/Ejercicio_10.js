const generarTabla = N => { 
    for (let i = 1; i <= 10; i++) {
        console.log(`${N} x ${i} = ${N * i}`);
    }
}
generarTabla(10);