let numeros=[5, 7, 8, 4, 9, 2, 1]
function darmepares(array){
    let pares=[];
    for(let i=0;i<array.lenght;i++){
        if(array[i]%2===0){
            pares.push(array[i]);
        }
    }
    return pares;
}
let arrayNuevo=darmepares(numeros);
console.log(arrayNuevo)