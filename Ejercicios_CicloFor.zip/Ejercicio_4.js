let texto="Carolina";
let contador=0;
for(let i=0;i<texto.length;i++){
    let valor=texto[i].toLowerCase();
    if(valor==='a'){
        contador++;
    }
}
console.log('encontre'+contador+'letras vocales a');