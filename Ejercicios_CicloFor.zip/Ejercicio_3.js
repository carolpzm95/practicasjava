function generartabla(numero) {
    for (let i=1;i<=10;i++){
        const resultado=numero*i;
        console.log (`${numero}x ${i}=${resultado}`);
    }
}
generartabla(8);