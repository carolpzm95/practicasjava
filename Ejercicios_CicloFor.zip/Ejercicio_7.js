function sumaCuadrados(N) {
    let sumaTotal = 0;
    for (let i = 1; i <= N; i++) {
        const cuadrado = i * i; 
        sumaTotal += cuadrado;
    }
    return sumaTotal;
}
console.log(sumaCuadrados(8)); 
console.log(sumaCuadrados(20));