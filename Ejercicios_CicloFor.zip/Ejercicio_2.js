let suma=0;
for(let i=1;i<=10;i++){
    suma+=i;
}
console.log("la suma es:"+suma);