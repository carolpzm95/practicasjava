# E-Sports

# Importar base de datos

Abrir phpMyAdmin o MySQL Workbench
Crear una base de datos que se llame: e_sports
Importar el archivo: base_datos.sql

# Instalar dependencias del backend

Abrir terminal: npm install

# Configurar conexión MySQL

En db.js ajustar usuario/contraseña si es necesario

# Iniciar backend

npm start

# Abrir el frontend

Abrir el archivo o carpeta con Live Server
