import { db } from "../db.js";

export const getPlataformas = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT 
                id_plataforma AS id,
                nombre,
                marca
            FROM plataforma
        `);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: "Error obteniendo plataformas" });
    }
};

export const createPlataforma = async (req, res) => {
    try {
        const { nombre, marca } = req.body;

        if (!nombre || !marca) {
            return res.status(400).json({ error: "Nombre y marca son obligatorios" });
        }

        await db.query(
            "INSERT INTO plataforma (nombre, marca) VALUES (?, ?)",
            [nombre, marca]
        );

        res.json({ message: "Plataforma creada" });
    } catch (error) {
        res.status(500).json({ error: "Error creando plataforma" });
    }
};

export const updatePlataforma = async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, marca } = req.body;

        await db.query(
            "UPDATE plataforma SET nombre=?, marca=? WHERE id_plataforma=?",
            [nombre, marca, id]
        );

        res.json({ message: "Plataforma actualizada" });
    } catch (error) {
        res.status(500).json({ error: "Error actualizando plataforma" });
    }
};

export const deletePlataforma = async (req, res) => {
    try {
        const { id } = req.params;

        await db.query("DELETE FROM plataforma WHERE id_plataforma=?", [id]);

        res.json({ message: "Plataforma eliminada" });
    } catch (error) {
        res.status(500).json({ error: "Error eliminando plataforma" });
    }
};