import { db } from "../db.js";

export const getJuegos = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT 
                id_juego AS id,
                nombre,
                tipo,
                estudio_dev,
                id_plataforma AS PLATAFORMA_id
            FROM juego
        `);

        res.json(rows);
    } catch (error) {
        console.error("Error al obtener juegos:", error);
        res.status(500).json({ error: "Error al obtener los juegos" });
    }
};

export const createJuego = async (req, res) => {
    try {
        const { nombre, tipo, estudio_dev, PLATAFORMA_id } = req.body;

        await db.query(
            `INSERT INTO juego (nombre, tipo, estudio_dev, id_plataforma)
             VALUES (?, ?, ?, ?)`,
            [nombre, tipo, estudio_dev, PLATAFORMA_id]
        );

        res.json({ message: "Juego creado" });
    } catch (error) {
        console.error("Error al crear juego:", error);
        res.status(500).json({ error: "Error al crear el juego" });
    }
};

export const updateJuego = async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, tipo, estudio_dev, PLATAFORMA_id } = req.body;

        await db.query(
            `UPDATE juego 
             SET nombre=?, tipo=?, estudio_dev=?, id_plataforma=?
             WHERE id_juego=?`,
            [nombre, tipo, estudio_dev, PLATAFORMA_id, id]
        );

        res.json({ message: "Juego actualizado" });
    } catch (error) {
        console.error("Error al actualizar juego:", error);
        res.status(500).json({ error: "Error al actualizar el juego" });
    }
};

export const deleteJuego = async (req, res) => {
    try {
        const { id } = req.params;

        await db.query(
            `DELETE FROM juego WHERE id_juego=?`,
            [id]
        );

        res.json({ message: "Juego eliminado" });
    } catch (error) {
        console.error("Error al eliminar juego:", error);
        res.status(500).json({ error: "Error al eliminar el juego" });
    }
};