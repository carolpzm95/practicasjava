import { db } from "../db.js";

export const getEquipos = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                id_equipo AS id,
                nombre,
                nivel,
                horas,
                id_juego AS JUEGO_id
            FROM equipo_juego
        `);

        res.json(rows);
    } catch (error) {
        console.error("Error al obtener equipos:", error);
        res.status(500).json({ error: "Error al obtener los equipos" });
    }
};

export const createEquipo = async (req, res) => {
    try {
        const { nombre, nivel, horas, JUEGO_id } = req.body;

        await db.query(
            `INSERT INTO equipo_juego (nombre, nivel, horas, id_juego)
             VALUES (?, ?, ?, ?)`,
            [nombre, nivel, horas, JUEGO_id]
        );

        res.json({ message: "Equipo creado" });
    } catch (error) {
        console.error("Error al crear equipo:", error);
        res.status(500).json({ error: "Error al crear el equipo" });
    }
};

export const updateEquipo = async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, nivel, horas, JUEGO_id } = req.body;

        await db.query(
            `UPDATE equipo_juego
             SET nombre=?, nivel=?, horas=?, id_juego=?
             WHERE id_equipo=?`,
            [nombre, nivel, horas, JUEGO_id, id]
        );

        res.json({ message: "Equipo actualizado" });
    } catch (error) {
        console.error("Error al actualizar equipo:", error);
        res.status(500).json({ error: "Error al actualizar el equipo" });
    }
};

export const deleteEquipo = async (req, res) => {
    try {
        const { id } = req.params;

        await db.query(`DELETE FROM equipo_juego WHERE id_equipo=?`, [id]);

        res.json({ message: "Equipo eliminado" });
    } catch (error) {
        console.error("Error al eliminar equipo:", error);
        res.status(500).json({ error: "Error al eliminar el equipo" });
    }
};