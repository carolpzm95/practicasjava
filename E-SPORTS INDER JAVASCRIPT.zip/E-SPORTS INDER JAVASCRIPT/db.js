import mysql from "mysql2/promise";

export const db = await mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "e_sports",
    waitForConnections: true,
    connectionLimit: 10
});

try {
    const connection = await db.getConnection();
    console.log("Conectado a MySQL correctamente");
    connection.release();
} catch (err) {
    console.error("Error conectando a MySQL:", err);
}