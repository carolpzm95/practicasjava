import { Router } from "express";
import {
    getPlataformas, 
    createPlataforma,
    updatePlataforma,
    deletePlataforma,
} from "../controllers/plataforma.controller.js";

const router = Router();

router.get("/", getPlataformas);
router.post("/", createPlataforma);
router.put("/:id", updatePlataforma);
router.delete("/:id", deletePlataforma);

export default router;