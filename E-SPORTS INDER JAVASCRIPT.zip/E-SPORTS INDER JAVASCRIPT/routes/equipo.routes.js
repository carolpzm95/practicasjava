import { Router } from "express";
import {
    getEquipos,
    createEquipo,
    updateEquipo,
    deleteEquipo
} from "../controllers/equipo.controller.js";

const router = Router();

router.get("/", getEquipos);
router.post("/", createEquipo);
router.put("/:id", updateEquipo);
router.delete("/:id", deleteEquipo);

export default router;