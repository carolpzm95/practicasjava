import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

import plataformaRoutes from "./routes/plataforma.routes.js";
import juegoRoutes from "./routes/juego.routes.js";
import equipoRoutes from "./routes/equipo.routes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, "frontend_esports-main")));

app.use("/plataformas", plataformaRoutes);
app.use("/juegos", juegoRoutes);
app.use("/equipos", equipoRoutes);

const PORT = 3000;

app.listen(PORT, () => {
    console.log("Servidor corriendo en puerto " + PORT);
    console.log("Abre en tu navegador: http://localhost:" + PORT);
});