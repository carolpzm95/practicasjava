//8.Leer un número e imprimir un mensaje en caso que sea múltiplo de 5.
let numero = 10;
numero = parseFloat(numero);
if (numero % 5 === 0) {
    console.log("El número " + numero + " es múltiplo de 5");
} else {
    console.log("El número " + numero + " NO es múltiplo de 5");
}