//9.Leer la edad de una persona e imprimir un mensaje en caso que sea mayor de edad
let edad = 20;
edad = parseInt(edad);
if (edad >= 18) {
    console.log("Usted es mayor de edad");
} else {
    console.log("Usted es menor de edad");
}