//5.Realizar un algoritmo que lea dos números e imprima la suma de los 2, en caso que el primero sea mayor al segundo
let numero1 = 26;
let numero2= 30;

if (numero1 > numero2) {
    console.log("la suma de los dos numeros es: " + (numero1 + numero2));
}  else { 
    console.log("El primer número no es mayor al segundo");
}