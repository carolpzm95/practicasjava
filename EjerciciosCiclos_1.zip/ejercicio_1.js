//1.Suponga que un individuo desea invertir su capital en un banco y desea saber cuánto dinero ganará después de un mes si el banco paga a razón de 2% mensual.
let capital= 200000;
let tasa = 0.2;
let total=capital * tasa;
console.log("Tu capital inicial es: $" + capital);
console.log("Ganarás de interés: $" + tasa);
console.log("Al final del mes tendrás: $" + total);