//3.Elabore un algoritmo que lea un número y si este es mayor o igual a 10 devuelva el triple de este
let numero = 20;
if (numero >= 10) {
  let triple = numero * 3;
  console.log("El número triple es:" +triple);
} else {
  console.log("El número no es mayor o igual a 10:" +numero);
}