//12.Hacer un algoritmo que calcule el total a pagar por la compra de camisas. Si se compran tres camisas o más se aplica un descuento del 20% sobre el total de la compra y si son menos de tres camisas un descuento del 10%
let cantidad = 10;
cantidad = parseInt(cantidad);
let precio = 50000;
precio = parseFloat(precio);
let total = cantidad * precio;
let totalPagar = 0;
if (cantidad >= 3) {
    totalPagar = total * 0.80;
} else {
    totalPagar = total * 0.90;
}
console.log("Cantidad de camisas: " + cantidad);
console.log("Precio por camisa: $" + precio);
console.log("Total sin descuento: $" + total);
console.log("Total a pagar: $" + totalPagar);