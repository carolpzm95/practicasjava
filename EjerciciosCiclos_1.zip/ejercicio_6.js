//7.Calcular el salario de un empleado, teniendo en cuenta que si el salario bruto es superior a $2.000.000, debe hacerse una retención del 10%.
let salario= 3000000;

if (salario > 200000) {
    retencion = salario * 0.10;  
    salarioTotal = salario - retencion;
    console.log("Salario de retención es:" + salarioTotal);
} else {
    console.log("Salario sin retención es:" + salario);
}