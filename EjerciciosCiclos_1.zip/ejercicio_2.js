//2.Leer un número e imprimir un mensaje en caso que sea par.
let numero= 13;
if (numero%2===0){
    console.log("el numero es par");
}else{
    console.log("el numero es impar");
}