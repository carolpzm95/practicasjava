//10.Un proveedor de computadores ofrece descuento del 10%, si cuesta $1.000.000 o más. Determinar cuánto pagará, con IVA incluido (19%), un cliente cualquiera por la compra de una computadora.
let precio = 2500000;
precio = parseFloat(precio);
let precioFinal = 0;
if (precio >= 1000000) {
    precioFinal = precio * 0.90 * 1.19; 
    console.log("Total a pagar con descuento e IVA: $" + precioFinal);
} else {
    precioFinal = precio * 1.19; 
    console.log("Total a pagar con IVA: $" + precioFinal);
}